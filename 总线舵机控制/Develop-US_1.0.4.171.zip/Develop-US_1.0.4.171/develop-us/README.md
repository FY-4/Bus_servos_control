# UART Servo Host Program

- Unzip the download file.

- Enter the folder and double click develop.exe.